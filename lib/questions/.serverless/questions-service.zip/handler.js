(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	const questionService_1 = __webpack_require__(1);
	function questions(event, context, callback) {
	    const done = (err, res) => callback(null, {
	        statusCode: err ? '400' : '200',
	        body: err ? err.message : JSON.stringify(res),
	        headers: { 'Content-Type': 'application/json' }
	    });
	    if (event.httpMethod === 'GET') {
	        let questionService = new questionService_1.QuestionService();
	        let questions = questionService.GetAll();
	        done(undefined, questions);
	    }
	    else
	        done(new Error(`Unsupported method "${event.httpMethod}"`), undefined);
	}
	exports.questions = questions;


/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	const testData_1 = __webpack_require__(2);
	//TODO: Implement Database
	class QuestionService {
	    GetAll() {
	        let data = new testData_1.TestData();
	        return [data.Question1, data.Question2];
	    }
	}
	exports.QuestionService = QuestionService;


/***/ },
/* 2 */
/***/ function(module, exports) {

	"use strict";
	class TestData {
	    constructor() {
	        this.compose();
	    }
	    ;
	    compose() {
	        var Question1Answer1 = {
	            title: "Question1Answer1"
	        };
	        var Question1Answer2 = {
	            title: "Question1Answer2"
	        };
	        this.Question1 = {
	            id: 1,
	            title: "What is your age?",
	            category: "about",
	            answers: [Question1Answer1, Question1Answer2]
	        };
	        var Question2Answer2 = {
	            title: "Question2Answer1"
	        };
	        this.Question2 = {
	            id: 2,
	            title: "What is your sex?",
	            category: "about",
	            answers: [
	                Question2Answer2
	            ]
	        };
	    }
	}
	exports.TestData = TestData;


/***/ }
/******/ ])));